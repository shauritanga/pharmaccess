-- Create normalized tables with norm_ prefix to avoid collisions
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS norm_regions (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  UNIQUE KEY uk_regions_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS norm_districts (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  region_id BIGINT UNSIGNED NOT NULL,
  name VARCHAR(120) NOT NULL,
  UNIQUE KEY uk_districts_region_name (region_id, name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS norm_shehia (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  district_id BIGINT UNSIGNED NOT NULL,
  name VARCHAR(160) NOT NULL,
  UNIQUE KEY uk_shehia_district_name (district_id, name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS norm_hfacilities (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(160) NOT NULL,
  legal_form VARCHAR(80) NULL,
  level VARCHAR(80) NULL,
  qpi_id INT NULL,
  certificate_awarded_level INT NULL,
  latitude DECIMAL(10,6) NULL,
  longitude DECIMAL(10,6) NULL,
  address VARCHAR(255) NULL,
  district_id BIGINT UNSIGNED NULL,
  shehia_id BIGINT UNSIGNED NULL,
  care_type VARCHAR(80) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS norm_patients (
  id BIGINT UNSIGNED PRIMARY KEY,
  open_imis_number VARCHAR(64) NULL,
  name VARCHAR(160) NULL,
  gender ENUM('male','female') NULL,
  date_of_birth DATE NULL,
  phone_number VARCHAR(40) NULL,
  ppi_score VARCHAR(64) NULL,
  district_id BIGINT UNSIGNED NULL,
  shehia_id BIGINT UNSIGNED NULL,
  date_joined DATE NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS norm_icd_codes (
  id BIGINT UNSIGNED PRIMARY KEY,
  code VARCHAR(16) NOT NULL,
  name VARCHAR(255) NOT NULL,
  UNIQUE KEY uk_icd_code (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS norm_visits (
  id BIGINT UNSIGNED PRIMARY KEY,
  patient_id BIGINT UNSIGNED NOT NULL,
  hfacility_id BIGINT UNSIGNED NULL,
  matibabu_id VARCHAR(64) NULL,
  claim_admin_id INT NULL,
  date_from DATE NULL,
  date_to DATE NULL,
  visit_context VARCHAR(120) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS norm_visit_types (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80) NOT NULL,
  UNIQUE KEY uk_visit_types_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS norm_visit_visit_types (
  visit_id BIGINT UNSIGNED NOT NULL,
  visit_type_id BIGINT UNSIGNED NOT NULL,
  PRIMARY KEY (visit_id, visit_type_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS norm_visit_diagnoses (
  visit_id BIGINT UNSIGNED NOT NULL,
  icd_id BIGINT UNSIGNED NOT NULL,
  diag_rank TINYINT UNSIGNED NOT NULL DEFAULT 1,
  PRIMARY KEY (visit_id, icd_id, diag_rank)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS norm_service_master (
  id BIGINT UNSIGNED PRIMARY KEY,
  name VARCHAR(160) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS norm_claim_services (
  id BIGINT UNSIGNED PRIMARY KEY,
  visit_id BIGINT UNSIGNED NOT NULL,
  service_id BIGINT UNSIGNED NOT NULL,
  qty_provided INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS norm_item_master (
  id BIGINT UNSIGNED PRIMARY KEY,
  name VARCHAR(160) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS norm_claim_items (
  id BIGINT UNSIGNED PRIMARY KEY,
  visit_id BIGINT UNSIGNED NOT NULL,
  item_id BIGINT UNSIGNED NOT NULL,
  qty_provided INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS norm_medication_master (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(160) NOT NULL,
  UNIQUE KEY uk_med_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS norm_meetings (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  patient_id BIGINT UNSIGNED NOT NULL,
  meeting_date DATE NOT NULL,
  systolic_bp INT NULL,
  diastolic_bp INT NULL,
  pr INT NULL,
  fbs DECIMAL(5,2) NULL,
  rbs DECIMAL(5,2) NULL,
  weight_kg DECIMAL(6,2) NULL,
  height_cm DECIMAL(6,2) NULL,
  bmi DECIMAL(6,2) NULL,
  UNIQUE KEY uk_meeting_patient_date (patient_id, meeting_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS norm_meeting_medications (
  meeting_id BIGINT UNSIGNED NOT NULL,
  medication_id BIGINT UNSIGNED NOT NULL,
  dose_mg INT NULL,
  pills_per_day INT NULL,
  pills_received INT NULL,
  PRIMARY KEY (meeting_id, medication_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS=1;

