-- Normalized schema (3NF-ish) derived from public/tables.sql
-- Engine/charset defaults
SET
  NAMES utf8mb4;

SET
  FOREIGN_KEY_CHECKS = 0;

-- Reference data: geography
CREATE TABLE
  IF NOT EXISTS regions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    UNIQUE KEY uk_regions_name (name)
  ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

CREATE TABLE
  IF NOT EXISTS districts (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    region_id BIGINT UNSIGNED NOT NULL,
    name VARCHAR(120) NOT NULL,
    UNIQUE KEY uk_districts_region_name (region_id, name),
    KEY idx_districts_region (region_id),
    CONSTRAINT fk_districts_region FOREIGN KEY (region_id) REFERENCES regions (id) ON UPDATE CASCADE ON DELETE RESTRICT
  ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

CREATE TABLE
  IF NOT EXISTS shehia (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    district_id BIGINT UNSIGNED NOT NULL,
    name VARCHAR(160) NOT NULL,
    UNIQUE KEY uk_shehia_district_name (district_id, name),
    KEY idx_shehia_district (district_id),
    CONSTRAINT fk_shehia_district FOREIGN KEY (district_id) REFERENCES districts (id) ON UPDATE CASCADE ON DELETE RESTRICT
  ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

-- Facilities
CREATE TABLE
  IF NOT EXISTS hfacilities (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(160) NOT NULL,
    legal_form VARCHAR(80) NULL,
    level VARCHAR(80) NULL,
    qpi_id INT NULL,
    certificate_awarded_level INT NULL,
    latitude DECIMAL(10, 6) NULL,
    longitude DECIMAL(10, 6) NULL,
    address VARCHAR(255) NULL,
    district_id BIGINT UNSIGNED NULL,
    shehia_id BIGINT UNSIGNED NULL,
    care_type VARCHAR(80) NULL,
    KEY idx_hf_district (district_id),
    KEY idx_hf_shehia (shehia_id),
    CONSTRAINT fk_hf_district FOREIGN KEY (district_id) REFERENCES districts (id) ON UPDATE CASCADE ON DELETE SET NULL,
    CONSTRAINT fk_hf_shehia FOREIGN KEY (shehia_id) REFERENCES shehia (id) ON UPDATE CASCADE ON DELETE SET NULL
  ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

-- Patients (Insuree)
CREATE TABLE
  IF NOT EXISTS patients (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    family_id INT NULL,
    open_imis_number VARCHAR(64) NULL,
    name VARCHAR(160) NULL,
    gender ENUM ('male', 'female') NULL,
    date_of_birth DATE NULL,
    phone_number VARCHAR(40) NULL,
    ppi_score VARCHAR(64) NULL,
    district_id BIGINT UNSIGNED NULL,
    shehia_id BIGINT UNSIGNED NULL,
    date_joined DATE NULL,
    UNIQUE KEY uk_patients_openimis (open_imis_number),
    KEY idx_patients_district (district_id),
    KEY idx_patients_shehia (shehia_id),
    CONSTRAINT fk_patients_district FOREIGN KEY (district_id) REFERENCES districts (id) ON UPDATE CASCADE ON DELETE SET NULL,
    CONSTRAINT fk_patients_shehia FOREIGN KEY (shehia_id) REFERENCES shehia (id) ON UPDATE CASCADE ON DELETE SET NULL
  ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

-- ICD codes (diagnoses)
CREATE TABLE
  IF NOT EXISTS icd_codes (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(16) NOT NULL,
    name VARCHAR(255) NOT NULL,
    UNIQUE KEY uk_icd_code (code)
  ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

-- Visit/Claim header (normalized VisitData)
CREATE TABLE
  IF NOT EXISTS visits (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, -- visit_id / claim_id
    patient_id BIGINT UNSIGNED NOT NULL,
    hfacility_id BIGINT UNSIGNED NULL,
    matibabu_id VARCHAR(64) NULL,
    claim_admin_id INT NULL,
    date_from DATE NULL,
    date_to DATE NULL,
    visit_context VARCHAR(120) NULL, -- e.g., outpatient/inpatient context text
    KEY idx_visits_patient (patient_id),
    KEY idx_visits_hf (hfacility_id),
    CONSTRAINT fk_visits_patient FOREIGN KEY (patient_id) REFERENCES patients (id) ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_visits_hf FOREIGN KEY (hfacility_id) REFERENCES hfacilities (id) ON UPDATE CASCADE ON DELETE SET NULL
  ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

-- Visit types (multiple per visit)
CREATE TABLE
  IF NOT EXISTS visit_types (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(80) NOT NULL,
    UNIQUE KEY uk_visit_types_name (name)
  ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

CREATE TABLE
  IF NOT EXISTS visit_visit_types (
    visit_id BIGINT UNSIGNED NOT NULL,
    visit_type_id BIGINT UNSIGNED NOT NULL,
    PRIMARY KEY (visit_id, visit_type_id),
    CONSTRAINT fk_vvt_visit FOREIGN KEY (visit_id) REFERENCES visits (id) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_vvt_type FOREIGN KEY (visit_type_id) REFERENCES visit_types (id) ON UPDATE CASCADE ON DELETE RESTRICT
  ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

-- Diagnoses: variable number per visit
CREATE TABLE
  IF NOT EXISTS visit_diagnoses (
    visit_id BIGINT UNSIGNED NOT NULL,
    icd_id BIGINT UNSIGNED NOT NULL,
    diag_rank TINYINT UNSIGNED NOT NULL DEFAULT 1, -- 1=primary, higher=secondary order
    PRIMARY KEY (visit_id, icd_id, diag_rank),
    KEY idx_vdiag_icd (icd_id),
    CONSTRAINT fk_vdiag_visit FOREIGN KEY (visit_id) REFERENCES visits (id) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_vdiag_icd FOREIGN KEY (icd_id) REFERENCES icd_codes (id) ON UPDATE CASCADE ON DELETE RESTRICT
  ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

-- Services
CREATE TABLE
  IF NOT EXISTS service_master (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(160) NOT NULL,
    UNIQUE KEY uk_service_name (name)
  ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

CREATE TABLE
  IF NOT EXISTS claim_services (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    visit_id BIGINT UNSIGNED NOT NULL,
    service_id BIGINT UNSIGNED NOT NULL,
    qty_provided INT NOT NULL DEFAULT 0,
    KEY idx_cs_visit (visit_id),
    KEY idx_cs_service (service_id),
    CONSTRAINT fk_cs_visit FOREIGN KEY (visit_id) REFERENCES visits (id) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_cs_service FOREIGN KEY (service_id) REFERENCES service_master (id) ON UPDATE CASCADE ON DELETE RESTRICT
  ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

-- Items (consumables)
CREATE TABLE
  IF NOT EXISTS item_master (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(160) NOT NULL,
    UNIQUE KEY uk_item_name (name)
  ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

CREATE TABLE
  IF NOT EXISTS claim_items (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    visit_id BIGINT UNSIGNED NOT NULL,
    item_id BIGINT UNSIGNED NOT NULL,
    qty_provided INT NOT NULL DEFAULT 0,
    KEY idx_ci_visit (visit_id),
    KEY idx_ci_item (item_id),
    CONSTRAINT fk_ci_visit FOREIGN KEY (visit_id) REFERENCES visits (id) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_ci_item FOREIGN KEY (item_id) REFERENCES item_master (id) ON UPDATE CASCADE ON DELETE RESTRICT
  ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

-- Medications (for groups meeting meds, and general usage)
CREATE TABLE
  IF NOT EXISTS medication_master (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(160) NOT NULL,
    UNIQUE KEY uk_med_name (name)
  ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

-- Risk profiles
CREATE TABLE
  IF NOT EXISTS risk_profiles (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    patient_id BIGINT UNSIGNED NOT NULL,
    visit_id BIGINT UNSIGNED NULL,
    ref_clinic VARCHAR(255) NULL,
    support_help VARCHAR(255) NULL,
    time_reach_clinic INT NULL,
    visits_during_preg INT NULL,
    pregnant_before TINYINT NULL,
    age_first_child INT NULL,
    children_before INT NULL,
    attend_health_facility VARCHAR(255) NULL,
    KEY idx_rp_patient (patient_id),
    KEY idx_rp_visit (visit_id),
    CONSTRAINT fk_rp_patient FOREIGN KEY (patient_id) REFERENCES patients (id) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_rp_visit FOREIGN KEY (visit_id) REFERENCES visits (id) ON UPDATE CASCADE ON DELETE SET NULL
  ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

CREATE TABLE
  IF NOT EXISTS risk_profile_conditions (
    risk_profile_id BIGINT UNSIGNED NOT NULL,
    condition_code VARCHAR(64) NOT NULL,
    condition_text VARCHAR(255) NULL,
    PRIMARY KEY (risk_profile_id, condition_code),
    CONSTRAINT fk_rpc_rp FOREIGN KEY (risk_profile_id) REFERENCES risk_profiles (id) ON UPDATE CASCADE ON DELETE CASCADE
  ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

-- Patient groups
CREATE TABLE
  IF NOT EXISTS `groups` (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(160) NOT NULL,
    UNIQUE KEY uk_groups_name (name)
  ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

CREATE TABLE
  IF NOT EXISTS group_memberships (
    group_id BIGINT UNSIGNED NOT NULL,
    patient_id BIGINT UNSIGNED NOT NULL,
    date_joined DATE NULL,
    PRIMARY KEY (group_id, patient_id),
    KEY idx_gm_patient (patient_id),
    CONSTRAINT fk_gm_group FOREIGN KEY (group_id) REFERENCES `groups` (id) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_gm_patient FOREIGN KEY (patient_id) REFERENCES patients (id) ON UPDATE CASCADE ON DELETE CASCADE
  ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

-- Meetings and vitals
CREATE TABLE
  IF NOT EXISTS meetings (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    patient_id BIGINT UNSIGNED NOT NULL,
    meeting_date DATE NOT NULL,
    systolic_bp INT NULL,
    diastolic_bp INT NULL,
    pr INT NULL,
    fbs DECIMAL(5, 2) NULL,
    rbs DECIMAL(5, 2) NULL,
    weight_kg DECIMAL(6, 2) NULL,
    height_cm DECIMAL(6, 2) NULL,
    bmi DECIMAL(6, 2) NULL,
    UNIQUE KEY uk_meeting_patient_date (patient_id, meeting_date),
    KEY idx_meet_patient (patient_id),
    CONSTRAINT fk_meet_patient FOREIGN KEY (patient_id) REFERENCES patients (id) ON UPDATE CASCADE ON DELETE CASCADE
  ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

CREATE TABLE
  IF NOT EXISTS meeting_medications (
    meeting_id BIGINT UNSIGNED NOT NULL,
    medication_id BIGINT UNSIGNED NOT NULL,
    dose_mg INT NULL,
    pills_per_day INT NULL,
    pills_received INT NULL,
    PRIMARY KEY (meeting_id, medication_id),
    KEY idx_mm_med (medication_id),
    CONSTRAINT fk_mm_meeting FOREIGN KEY (meeting_id) REFERENCES meetings (id) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_mm_med FOREIGN KEY (medication_id) REFERENCES medication_master (id) ON UPDATE CASCADE ON DELETE RESTRICT
  ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

SET
  FOREIGN_KEY_CHECKS = 1;