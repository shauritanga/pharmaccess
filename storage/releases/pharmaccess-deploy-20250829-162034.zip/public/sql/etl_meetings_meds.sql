-- ETL: Groups meetings and medications
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;

-- 1) Meetings from stage_GroupsMeetingData (patient must exist)
INSERT IGNORE INTO meetings (patient_id, meeting_date, systolic_bp, diastolic_bp, pr, fbs, rbs, weight_kg, height_cm, bmi)
SELECT
  gmd.Patient_number,
  gmd.Meeting_date,
  gmd.Systolic_BP,
  gmd.Diastolic_BP,
  gmd.PR,
  gmd.FBS,
  gmd.RBS,
  gmd.Weight_KG,
  gmd.Height_cm,
  gmd.BMI
FROM stage_GroupsMeetingData gmd
JOIN patients p ON p.id = gmd.Patient_number;

-- 2) Medications master from names, if any exist in meetings data
INSERT IGNORE INTO medication_master(name)
SELECT DISTINCT TRIM(Medication_1)
FROM stage_GroupsMeetingData
WHERE Medication_1 IS NOT NULL AND TRIM(Medication_1)<>'';

-- 3) Meeting medications (assuming one medication column; extend if more)
INSERT IGNORE INTO meeting_medications (meeting_id, medication_id, dose_mg, pills_per_day, pills_received)
SELECT m.id, mm.id,
       gmd.num_of_mgs_1,
       gmd.num_of_pills_1,
       gmd.num_of_pills_received_1
FROM stage_GroupsMeetingData gmd
JOIN meetings m ON m.patient_id = gmd.Patient_number AND m.meeting_date = gmd.Meeting_date
JOIN medication_master mm ON mm.name = TRIM(gmd.Medication_1);

SET FOREIGN_KEY_CHECKS=1;

