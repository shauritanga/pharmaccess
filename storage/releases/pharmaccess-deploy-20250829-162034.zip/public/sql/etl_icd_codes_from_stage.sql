-- ETL: load ICD codes from staging into normalized icd_codes
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;

INSERT INTO icd_codes (id, code, name)
SELECT s.ICDID, s.ICDCode, s.ICDName
FROM stage_tblICDCodes s
ON DUPLICATE KEY UPDATE code=VALUES(code), name=VALUES(name);

-- Set next auto-increment to max(id)+1
SET @next_ai = (SELECT COALESCE(MAX(id),0)+1 FROM icd_codes);
SET @sql = CONCAT('ALTER TABLE icd_codes AUTO_INCREMENT = ', @next_ai);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET FOREIGN_KEY_CHECKS=1;

