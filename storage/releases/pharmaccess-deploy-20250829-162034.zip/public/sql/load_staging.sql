-- Load CSVs into staging tables (adjust LOCAL INFILE permissions if needed)
SET
    NAMES utf8mb4;

-- VisitData
LOAD DATA LOCAL INFILE 'public/data/VisitData(Utilization Data).csv' INTO TABLE stage_VisitData CHARACTER
SET
    latin1 FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\n' IGNORE 1 LINES (
        ClaimID,
        InsureeID,
        FamilyID,
        MatibabuID,
        PPIScore,
        Gender,
        DateFrom,
        DateTo,
        ICDID,
        HFID,
        HFName,
        ClaimAdminId,
        ICDID1,
        ICDID2,
        ICDID3,
        ICDID4,
        VisitType,
        VisitType2,
        VisitType3,
        DOB,
        DistrictName,
        Shehia
    );

-- Services
LOAD DATA LOCAL INFILE 'public/data/Services(Services).csv' INTO TABLE stage_Services CHARACTER
SET
    latin1 FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\n' IGNORE 1 LINES (
        ClaimServiceID,
        ClaimID,
        ServiceID,
        ServName,
        QtyProvided
    );

-- Items
LOAD DATA LOCAL INFILE 'public/data/Items(in).csv' INTO TABLE stage_Items CHARACTER
SET
    latin1 FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\n' IGNORE 1 LINES (
        ClaimItemID,
        ClaimID,
        ItemID,
        ItemName,
        QtyProvided
    );

-- RiskProfile
LOAD DATA LOCAL INFILE 'public/data/RiskProfile(in).csv' INTO TABLE stage_RiskProfile CHARACTER
SET
    latin1 FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\n' IGNORE 1 LINES (
        RiskProfileID,
        InsureeID,
        ClaimID,
        RefClinic,
        SupportHelp,
        TimeReachClinic,
        VisitsDuringPreg,
        HealthConditions,
        PregnantBefore,
        AgeFirstChild,
        ChildrenBefore,
        ComplicationPreviousPregnancies,
        AttendHealthFacility
    );

-- Hfacility (if CSV provided in future)
-- LOAD DATA LOCAL INFILE 'public/data/Hfacility.csv' INTO TABLE stage_Hfacility ...
-- GroupsDemographics
LOAD DATA LOCAL INFILE 'public/data/demographic_data.csv' INTO TABLE stage_GroupsDemographics CHARACTER
SET
    latin1 FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\n' IGNORE 1 LINES (
        Group_name,
        Patient_number,
        Patient_name,
        open_IMIS_number,
        Age,
        Gender,
        Diagnosis_HT_DM_HT_DM,
        Shehia,
        phone_number,
        date_joined
    );

-- GroupsMeetingData
LOAD DATA LOCAL INFILE 'public/data/meeting_data.csv' INTO TABLE stage_GroupsMeetingData CHARACTER
SET
    latin1 FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\n' IGNORE 1 LINES (
        Patient_number,
        Meeting_date,
        Systolic_BP,
        Diastolic_BP,
        PR,
        FBS,
        RBS,
        Weight_KG,
        Height_cm,
        BMI,
        Medication_1,
        num_of_mgs_1,
        num_of_pills_1,
        num_of_pills_received_1
    );

-- ICD codes (Windows line endings)
TRUNCATE TABLE stage_tblICDCodes;

LOAD DATA LOCAL INFILE 'public/data/tblICDCodes(tblICDCodes-20250729).csv' INTO TABLE stage_tblICDCodes CHARACTER
SET
    utf8mb4 FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"' LINES TERMINATED BY '\r\n' IGNORE 1 LINES (ICDID, ICDCode, ICDName);