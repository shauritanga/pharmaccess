-- Indexes tailored for dashboard analytics performance
-- visits: filter/group by date and facility
ALTER TABLE visits ADD INDEX idx_visits_date_from (date_from),
ADD INDEX idx_visits_fac_date (hfacility_id, date_from);

-- visit_diagnoses: by disease then visit
ALTER TABLE visit_diagnoses ADD INDEX idx_vd_icd_visit (icd_id, visit_id);

-- meetings: time-based queries
ALTER TABLE meetings ADD INDEX idx_meet_date_patient (meeting_date, patient_id);

-- meeting_medications: by medication then meeting for trend aggregation
ALTER TABLE meeting_medications ADD INDEX idx_mm_med_meet (medication_id, meeting_id);

-- prescriptions: meds by patient over time
ALTER TABLE prescriptions ADD INDEX idx_pr_date_patient (prescribed_date, patient_id);

-- facilities by shehia
ALTER TABLE hfacilities ADD INDEX idx_hf_shehia_id (shehia_id, id);

-- patients: current schema lacks shehia_id; use district for locality filtering if needed
ALTER TABLE patients ADD INDEX idx_pat_district_id (district_id, id);