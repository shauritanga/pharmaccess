-- ETL: Services and Items from staging into normalized masters and claim lines
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;

-- 1) Service master from distinct names (fallback to ServiceID if name is null)
INSERT IGNORE INTO service_master(id, name)
SELECT DISTINCT s.ServiceID, COALESCE(NULLIF(TRIM(s.ServName), ''), CONCAT('Service-', s.ServiceID))
FROM stage_Services s
WHERE s.ServiceID IS NOT NULL;

-- 2) Item master
INSERT IGNORE INTO item_master(id, name)
SELECT DISTINCT i.ItemID, COALESCE(NULLIF(TRIM(i.ItemName), ''), CONCAT('Item-', i.ItemID))
FROM stage_Items i
WHERE i.ItemID IS NOT NULL;

-- 3) Claim services linked to visits
INSERT IGNORE INTO claim_services(id, visit_id, service_id, qty_provided)
SELECT s.ClaimServiceID, s.ClaimID, s.ServiceID, COALESCE(s.QtyProvided,0)
FROM stage_Services s
JOIN visits v ON v.id = s.ClaimID;

-- 4) Claim items linked to visits
INSERT IGNORE INTO claim_items(id, visit_id, item_id, qty_provided)
SELECT i.ClaimItemID, i.ClaimID, i.ItemID, COALESCE(i.QtyProvided,0)
FROM stage_Items i
JOIN visits v ON v.id = i.ClaimID;

SET FOREIGN_KEY_CHECKS=1;

