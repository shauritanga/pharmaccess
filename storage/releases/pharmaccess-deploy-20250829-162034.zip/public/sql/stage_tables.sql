-- Staging tables mirroring legacy CSVs (load as-is, then ETL to normalized)
SET
  NAMES utf8mb4;

SET
  FOREIGN_KEY_CHECKS = 0;

CREATE TABLE
  IF NOT EXISTS stage_tblICDCodes (
    ICDID INT PRIMARY KEY,
    ICDCode VARCHAR(32),
    ICDName VARCHAR(255)
  ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

CREATE TABLE
  IF NOT EXISTS stage_VisitData (
    ClaimID INT PRIMARY KEY,
    InsureeID INT,
    FamilyID INT,
    MatibabuID VARCHAR(255),
    PPIScore VARCHAR(255),
    Gender VARCHAR(64),
    DateFrom VARCHAR(32),
    DateTo VARCHAR(32),
    ICDID INT,
    HFID INT,
    HFName VARCHAR(255),
    ClaimAdminId INT,
    ICDID1 INT,
    ICDID2 INT,
    ICDID3 INT,
    ICDID4 INT,
    VisitType VARCHAR(255),
    VisitType2 VARCHAR(255),
    VisitType3 VARCHAR(255),
    DOB VARCHAR(32),
    DistrictName VARCHAR(255),
    Shehia VARCHAR(255)
  ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

CREATE TABLE
  IF NOT EXISTS stage_Services (
    ClaimServiceID INT PRIMARY KEY,
    ClaimID INT,
    ServiceID INT,
    ServName VARCHAR(255),
    QtyProvided INT
  ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

CREATE TABLE
  IF NOT EXISTS stage_Items (
    ClaimItemID INT PRIMARY KEY,
    ClaimID INT,
    ItemID INT,
    ItemName VARCHAR(255),
    QtyProvided INT
  ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

CREATE TABLE
  IF NOT EXISTS stage_RiskProfile (
    RiskProfileID INT PRIMARY KEY,
    InsureeID INT,
    ClaimID INT,
    RefClinic VARCHAR(255),
    SupportHelp VARCHAR(255),
    TimeReachClinic INT,
    VisitsDuringPreg INT,
    HealthConditions VARCHAR(255),
    PregnantBefore INT,
    AgeFirstChild INT,
    ChildrenBefore INT,
    ComplicationPreviousPregnancies VARCHAR(255),
    AttendHealthFacility VARCHAR(255)
  ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

CREATE TABLE
  IF NOT EXISTS stage_Hfacility (
    HfID INT PRIMARY KEY,
    HFName VARCHAR(255),
    LegalForm VARCHAR(255),
    HFLevel VARCHAR(255),
    QPID INT,
    certificateAwardedLevel INT,
    latitude DECIMAL(10, 6),
    longitude DECIMAL(10, 6),
    HFAddress VARCHAR(255),
    LocationId INT,
    HFCareType VARCHAR(255),
    District VARCHAR(255),
    Region VARCHAR(255)
  ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

CREATE TABLE
  IF NOT EXISTS stage_GroupsDemographics (
    Group_name VARCHAR(255),
    Patient_number INT PRIMARY KEY,
    Patient_name VARCHAR(255),
    open_IMIS_number VARCHAR(255),
    Age INT,
    Gender VARCHAR(64),
    Diagnosis_HT_DM_HT_DM VARCHAR(255),
    Shehia VARCHAR(255),
    phone_number VARCHAR(255),
    date_joined DATE
  ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

CREATE TABLE
  IF NOT EXISTS stage_GroupsMeetingData (
    Patient_number INT,
    Meeting_date DATE,
    Systolic_BP INT,
    Diastolic_BP INT,
    PR INT,
    FBS DECIMAL(5, 2),
    RBS DECIMAL(5, 2),
    Weight_KG DECIMAL(6, 2),
    Height_cm DECIMAL(6, 2),
    BMI DECIMAL(6, 2),
    Medication_1 VARCHAR(255),
    num_of_mgs_1 INT,
    num_of_pills_1 INT,
    num_of_pills_received_1 INT,
    PRIMARY KEY (Patient_number, Meeting_date)
  ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

SET
  FOREIGN_KEY_CHECKS = 1;