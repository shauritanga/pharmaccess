-- Direct ETL from staging CSVs into existing app tables used by UI
-- This avoids table name collisions and gets the UI working now
SET
  NAMES utf8mb4;

SET
  collation_connection = 'utf8mb4_unicode_ci';

SET
  FOREIGN_KEY_CHECKS = 0;

-- 0) Ensure an 'Unknown' district exists
INSERT INTO
  districts (name)
SELECT
  'Unknown'
WHERE
  NOT EXISTS (
    SELECT
      1
    FROM
      districts
    WHERE
      name = 'Unknown'
  );

-- 1) Districts from VisitData (distinct names)
INSERT IGNORE INTO districts (name)
SELECT DISTINCT
  TRIM(DistrictName)
FROM
  stage_VisitData
WHERE
  DistrictName IS NOT NULL
  AND TRIM(DistrictName) <> '';

-- 2) Patients from GroupsDemographics (preferred source)
INSERT INTO
  patients (
    id,
    gender,
    age,
    age_group,
    economic_status,
    district_id,
    created_at,
    updated_at
  )
SELECT
  gd.Patient_number AS id,
  CASE LOWER(TRIM(gd.Gender))
    WHEN 'm' THEN 'male'
    WHEN 'male' THEN 'male'
    WHEN 'f' THEN 'female'
    WHEN 'female' THEN 'female'
    ELSE 'other'
  END AS gender,
  COALESCE(NULLIF(gd.Age, 0), 0) AS age,
  CASE
    WHEN gd.Age IS NULL THEN '18-35'
    WHEN gd.Age <= 5 THEN '0-5'
    WHEN gd.Age <= 17 THEN '6-17'
    WHEN gd.Age <= 35 THEN '18-35'
    WHEN gd.Age <= 55 THEN '36-55'
    ELSE '56+'
  END AS age_group,
  'middle' AS economic_status,
  COALESCE(
    d.id,
    (
      SELECT
        id
      FROM
        districts
      WHERE
        name = 'Unknown'
      LIMIT
        1
    )
  ) AS district_id,
  CURRENT_TIMESTAMP,
  CURRENT_TIMESTAMP
FROM
  stage_GroupsDemographics gd
  LEFT JOIN districts d ON d.name COLLATE utf8mb4_unicode_ci = TRIM(gd.Shehia) COLLATE utf8mb4_unicode_ci -- if Shehia values match district names; will be corrected by VisitData fallback below
  ON DUPLICATE KEY
UPDATE gender =
VALUES
  (gender),
  age =
VALUES
  (age),
  age_group =
VALUES
  (age_group),
  economic_status =
VALUES
  (economic_status),
  district_id = COALESCE(
    VALUES
      (district_id),
      district_id
  ),
  updated_at = CURRENT_TIMESTAMP;

-- 2b) Fallback: set patient district using VisitData.DistrictName when not set
UPDATE patients p
JOIN (
  SELECT
    InsureeID,
    MAX(DistrictName) AS DistrictName
  FROM
    stage_VisitData
  WHERE
    DistrictName IS NOT NULL
    AND TRIM(DistrictName) <> ''
  GROUP BY
    InsureeID
) vd ON vd.InsureeID = p.id
JOIN districts d ON d.name COLLATE utf8mb4_unicode_ci = TRIM(vd.DistrictName) COLLATE utf8mb4_unicode_ci
SET
  p.district_id = COALESCE(
    p.district_id,
    d.id,
    (
      SELECT
        id
      FROM
        districts
      WHERE
        name = 'Unknown'
      LIMIT
        1
    )
  );

-- 3) Insert any missing patients from VisitData by InsureeID
INSERT INTO
  patients (
    id,
    gender,
    age,
    age_group,
    economic_status,
    district_id,
    created_at,
    updated_at
  )
SELECT DISTINCT
  v.InsureeID AS id,
  CASE LOWER(TRIM(v.Gender))
    WHEN 'm' THEN 'male'
    WHEN 'male' THEN 'male'
    WHEN 'f' THEN 'female'
    WHEN 'female' THEN 'female'
    ELSE 'other'
  END AS gender,
  COALESCE(
    CASE
      WHEN v.DOB LIKE '%/%/%' THEN TIMESTAMPDIFF (
        YEAR,
        STR_TO_DATE (v.DOB, '%m/%e/%Y'),
        CURRENT_DATE
      )
      WHEN v.DOB LIKE '____-__-__' THEN TIMESTAMPDIFF (
        YEAR,
        STR_TO_DATE (v.DOB, '%Y-%m-%d'),
        CURRENT_DATE
      )
      ELSE NULL
    END,
    0
  ) AS age,
  '18-35' AS age_group,
  'middle' AS economic_status,
  COALESCE(
    d.id,
    (
      SELECT
        id
      FROM
        districts
      WHERE
        name = 'Unknown'
      LIMIT
        1
    )
  ) AS district_id,
  CURRENT_TIMESTAMP,
  CURRENT_TIMESTAMP
FROM
  stage_VisitData v
  LEFT JOIN districts d ON d.name COLLATE utf8mb4_unicode_ci = TRIM(v.DistrictName) COLLATE utf8mb4_unicode_ci
  LEFT JOIN patients p ON p.id = v.InsureeID
WHERE
  p.id IS NULL;

-- 4) Diseases master from ICD staging
INSERT IGNORE INTO diseases (
  name,
  description,
  category,
  created_at,
  updated_at
)
SELECT
  s.ICDName,
  CONCAT ('ICD code: ', s.ICDCode),
  'infectious',
  CURRENT_TIMESTAMP,
  CURRENT_TIMESTAMP
FROM
  stage_tblICDCodes s;

-- 5) Disease cases from VisitData, mapping ICDID -> ICDName -> diseases.id
INSERT INTO
  disease_cases (
    disease_id,
    patient_id,
    reported_date,
    status,
    severity,
    created_at,
    updated_at
  )
SELECT
  d.id,
  v.InsureeID AS patient_id,
  CASE
    WHEN v.DateFrom LIKE '%/%/%' THEN COALESCE(
      STR_TO_DATE (v.DateFrom, '%m/%e/%Y %H:%i'),
      STR_TO_DATE (v.DateFrom, '%m/%e/%Y')
    )
    WHEN v.DateFrom LIKE '____-__-__ __:__:__' THEN STR_TO_DATE (v.DateFrom, '%Y-%m-%d %H:%i:%s')
    WHEN v.DateFrom LIKE '____-__-__ __:__' THEN STR_TO_DATE (v.DateFrom, '%Y-%m-%d %H:%i')
    WHEN v.DateFrom LIKE '____-__-__' THEN STR_TO_DATE (v.DateFrom, '%Y-%m-%d')
    ELSE NULL
  END AS reported_date,
  'active' AS status,
  'mild' AS severity,
  CURRENT_TIMESTAMP,
  CURRENT_TIMESTAMP
FROM
  stage_VisitData v
  JOIN stage_tblICDCodes ic ON ic.ICDID = v.ICDID
  JOIN diseases d ON d.name COLLATE utf8mb4_unicode_ci = ic.ICDName COLLATE utf8mb4_unicode_ci
  JOIN patients p ON p.id = v.InsureeID
  LEFT JOIN disease_cases dc ON dc.disease_id = d.id
  AND dc.patient_id = v.InsureeID
  AND dc.reported_date = STR_TO_DATE (v.DateFrom, '%m/%e/%Y %H:%i')
WHERE
  dc.id IS NULL;

-- 5b) Secondary diagnoses ICDID1..ICDID4
INSERT INTO
  disease_cases (
    disease_id,
    patient_id,
    reported_date,
    status,
    severity,
    created_at,
    updated_at
  )
SELECT
  d.id,
  v.InsureeID,
  CASE
    WHEN v.DateFrom LIKE '%/%/%' THEN COALESCE(
      STR_TO_DATE (v.DateFrom, '%m/%e/%Y %H:%i'),
      STR_TO_DATE (v.DateFrom, '%m/%e/%Y')
    )
    WHEN v.DateFrom LIKE '____-__-__ __:__:__' THEN STR_TO_DATE (v.DateFrom, '%Y-%m-%d %H:%i:%s')
    WHEN v.DateFrom LIKE '____-__-__ __:__' THEN STR_TO_DATE (v.DateFrom, '%Y-%m-%d %H:%i')
    WHEN v.DateFrom LIKE '____-__-__' THEN STR_TO_DATE (v.DateFrom, '%Y-%m-%d')
    ELSE NULL
  END,
  'active',
  'mild',
  CURRENT_TIMESTAMP,
  CURRENT_TIMESTAMP
FROM
  (
    SELECT
      ClaimID,
      InsureeID,
      DateFrom,
      ICDID1 AS ICDID
    FROM
      stage_VisitData
    WHERE
      ICDID1 IS NOT NULL
    UNION ALL
    SELECT
      ClaimID,
      InsureeID,
      DateFrom,
      ICDID2
    FROM
      stage_VisitData
    WHERE
      ICDID2 IS NOT NULL
    UNION ALL
    SELECT
      ClaimID,
      InsureeID,
      DateFrom,
      ICDID3
    FROM
      stage_VisitData
    WHERE
      ICDID3 IS NOT NULL
    UNION ALL
    SELECT
      ClaimID,
      InsureeID,
      DateFrom,
      ICDID4
    FROM
      stage_VisitData
    WHERE
      ICDID4 IS NOT NULL
  ) v
  JOIN stage_tblICDCodes ic ON ic.ICDID = v.ICDID
  JOIN diseases d ON d.name COLLATE utf8mb4_unicode_ci = ic.ICDName COLLATE utf8mb4_unicode_ci
  JOIN patients p ON p.id = v.InsureeID ON DUPLICATE KEY
UPDATE updated_at = CURRENT_TIMESTAMP;

-- 6) Medications master from meeting data
INSERT IGNORE INTO medications (
  name,
  description,
  category,
  dosage_form,
  strength,
  manufacturer,
  created_at,
  updated_at
)
SELECT DISTINCT
  TRIM(Medication_1) AS name,
  NULL,
  'other',
  'tablet',
  NULL,
  NULL,
  CURRENT_TIMESTAMP,
  CURRENT_TIMESTAMP
FROM
  stage_GroupsMeetingData
WHERE
  Medication_1 IS NOT NULL
  AND TRIM(Medication_1) <> '';

-- 7) Prescriptions from meetings
INSERT INTO
  prescriptions (
    medication_id,
    patient_id,
    prescribed_date,
    quantity,
    dosage,
    duration_days,
    status,
    prescribed_by,
    created_at,
    updated_at
  )
SELECT
  meds.id,
  gmd.Patient_number AS patient_id,
  gmd.Meeting_date AS prescribed_date,
  COALESCE(gmd.num_of_pills_received_1, 0) AS quantity,
  CONCAT (COALESCE(gmd.num_of_mgs_1, 0), ' mg') AS dosage,
  NULL AS duration_days,
  'active' AS status,
  NULL AS prescribed_by,
  CURRENT_TIMESTAMP,
  CURRENT_TIMESTAMP
FROM
  stage_GroupsMeetingData gmd
  JOIN medications meds ON meds.name COLLATE utf8mb4_unicode_ci = TRIM(gmd.Medication_1) COLLATE utf8mb4_unicode_ci
  JOIN patients p ON p.id = gmd.Patient_number ON DUPLICATE KEY
UPDATE quantity =
VALUES
  (quantity),
  prescribed_date =
VALUES
  (prescribed_date),
  dosage =
VALUES
  (dosage),
  status =
VALUES
  (status),
  updated_at = CURRENT_TIMESTAMP;

SET
  FOREIGN_KEY_CHECKS = 1;