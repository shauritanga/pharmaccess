-- Load ICD codes from CSV directly into normalized icd_codes
-- Assumes file: public/data/tblICDCodes(tblICDCodes-20250729).csv
-- Columns: ICDID,ICDCode,ICDName

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;

LOAD DATA LOCAL INFILE 'public/data/tblICDCodes(tblICDCodes-20250729).csv'
INTO TABLE icd_codes
FIELDS TERMINATED BY ',' ENCLOSED BY '"'
LINES TERMINATED BY '\n' IGNORE 1 LINES
(@ICDID,@ICDCode,@ICDName)
SET id=@ICDID, code=@ICDCode, name=@ICDName;

-- Ensure next auto-increment continues after imported IDs
SET @next_ai = (SELECT COALESCE(MAX(id),0)+1 FROM icd_codes);
SET @sql = CONCAT('ALTER TABLE icd_codes AUTO_INCREMENT = ', @next_ai);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET FOREIGN_KEY_CHECKS=1;

