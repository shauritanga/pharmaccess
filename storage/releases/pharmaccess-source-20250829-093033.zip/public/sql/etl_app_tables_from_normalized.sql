-- ETL to populate existing Laravel app tables from normalized schema
-- This keeps the current UI working without code changes
SET
  NAMES utf8mb4;

SET
  FOREIGN_KEY_CHECKS = 0;

-- 0) Diseases master from icd_codes (name + optional code into description)
INSERT IGNORE INTO diseases (
  name,
  description,
  category,
  created_at,
  updated_at
)
SELECT
  ic.name,
  CONCAT ('ICD code: ', ic.code),
  'infectious',
  CURRENT_TIMESTAMP,
  CURRENT_TIMESTAMP
FROM
  norm_icd_codes ic;

-- 1) Medications master from medication_master
INSERT IGNORE INTO medications (
  name,
  description,
  category,
  dosage_form,
  strength,
  manufacturer,
  created_at,
  updated_at
)
SELECT
  mm.name,
  NULL,
  'other',
  'tablet',
  NULL,
  NULL,
  CURRENT_TIMESTAMP,
  CURRENT_TIMESTAMP
FROM
  norm_medication_master mm;

-- 2) Patients table (app shape): id, gender, age, age_group, economic_status, district_id
-- Derive age from normalized patients.date_of_birth when available; else fallback from staging GroupsDemographics.Age
INSERT INTO
  patients (
    id,
    gender,
    age,
    age_group,
    economic_status,
    district_id,
    created_at,
    updated_at
  )
SELECT
  p.id,
  COALESCE(
    p.gender,
    CASE LOWER(TRIM(gd.Gender))
      WHEN 'm' THEN 'male'
      WHEN 'male' THEN 'male'
      WHEN 'f' THEN 'female'
      WHEN 'female' THEN 'female'
      ELSE 'other'
    END
  ) AS gender,
  COALESCE(
    CASE
      WHEN p.date_of_birth IS NOT NULL THEN TIMESTAMPDIFF (YEAR, p.date_of_birth, CURRENT_DATE)
    END,
    NULLIF(gd.Age, 0),
    0
  ) AS age,
  CASE
    WHEN p.date_of_birth IS NOT NULL THEN CASE
      WHEN TIMESTAMPDIFF (YEAR, p.date_of_birth, CURRENT_DATE) <= 5 THEN '0-5'
      WHEN TIMESTAMPDIFF (YEAR, p.date_of_birth, CURRENT_DATE) <= 17 THEN '6-17'
      WHEN TIMESTAMPDIFF (YEAR, p.date_of_birth, CURRENT_DATE) <= 35 THEN '18-35'
      WHEN TIMESTAMPDIFF (YEAR, p.date_of_birth, CURRENT_DATE) <= 55 THEN '36-55'
      ELSE '56+'
    END
    WHEN gd.Age IS NOT NULL THEN CASE
      WHEN gd.Age <= 5 THEN '0-5'
      WHEN gd.Age <= 17 THEN '6-17'
      WHEN gd.Age <= 35 THEN '18-35'
      WHEN gd.Age <= 55 THEN '36-55'
      ELSE '56+'
    END
    ELSE '18-35'
  END AS age_group,
  'middle' AS economic_status, -- TODO: map from PPI if you have a policy
  COALESCE(
    p.district_id,
    (
      SELECT
        id
      FROM
        districts
      WHERE
        name = 'Unknown'
      LIMIT
        1
    )
  ) AS district_id,
  CURRENT_TIMESTAMP,
  CURRENT_TIMESTAMP
FROM
  norm_patients p
  LEFT JOIN stage_GroupsDemographics gd ON gd.Patient_number = p.id ON DUPLICATE KEY
UPDATE gender =
VALUES
  (gender),
  age =
VALUES
  (age),
  age_group =
VALUES
  (age_group),
  economic_status =
VALUES
  (economic_status),
  district_id =
VALUES
  (district_id),
  updated_at = CURRENT_TIMESTAMP;

-- 2b) Fill missing patient DOB from VisitData.DOB (format M/D/YYYY)
UPDATE patients p
JOIN stage_VisitData sv ON sv.InsureeID = p.id
SET
  p.age = COALESCE(
    p.age,
    TIMESTAMPDIFF (
      YEAR,
      STR_TO_DATE (sv.DOB, '%m/%e/%Y'),
      CURRENT_DATE
    )
  ),
  p.age_group = COALESCE(
    p.age_group,
    CASE
      WHEN TIMESTAMPDIFF (
        YEAR,
        STR_TO_DATE (sv.DOB, '%m/%e/%Y'),
        CURRENT_DATE
      ) <= 5 THEN '0-5'
      WHEN TIMESTAMPDIFF (
        YEAR,
        STR_TO_DATE (sv.DOB, '%m/%e/%Y'),
        CURRENT_DATE
      ) <= 17 THEN '6-17'
      WHEN TIMESTAMPDIFF (
        YEAR,
        STR_TO_DATE (sv.DOB, '%m/%e/%Y'),
        CURRENT_DATE
      ) <= 35 THEN '18-35'
      WHEN TIMESTAMPDIFF (
        YEAR,
        STR_TO_DATE (sv.DOB, '%m/%e/%Y'),
        CURRENT_DATE
      ) <= 55 THEN '36-55'
      ELSE '56+'
    END
  );

-- 3) Disease cases from visits + visit_diagnoses, map icd to diseases by name
INSERT INTO
  disease_cases (
    disease_id,
    patient_id,
    reported_date,
    status,
    severity,
    created_at,
    updated_at
  )
SELECT
  d.id AS disease_id,
  v.patient_id,
  COALESCE(v.date_from, v.date_to) AS reported_date,
  'active' AS status,
  'mild' AS severity,
  CURRENT_TIMESTAMP,
  CURRENT_TIMESTAMP
FROM
  norm_visit_diagnoses vd
  JOIN norm_visits v ON v.id = vd.visit_id
  JOIN norm_icd_codes ic ON ic.id = vd.icd_id
  JOIN diseases d ON d.name COLLATE utf8mb4_unicode_ci = ic.name COLLATE utf8mb4_unicode_ci
WHERE
  NOT EXISTS (
    SELECT
      1
    FROM
      disease_cases dc
    WHERE
      dc.disease_id = d.id
      AND dc.patient_id = v.patient_id
      AND dc.reported_date = COALESCE(v.date_from, v.date_to)
  );

-- 4) Prescriptions from meetings + meeting_medications
INSERT INTO
  prescriptions (
    medication_id,
    patient_id,
    prescribed_date,
    quantity,
    dosage,
    duration_days,
    status,
    prescribed_by,
    created_at,
    updated_at
  )
SELECT
  meds.id AS medication_id,
  m.patient_id,
  m.meeting_date AS prescribed_date,
  COALESCE(mm.pills_received, 0) AS quantity,
  CONCAT (COALESCE(mm.dose_mg, 0), ' mg') AS dosage,
  NULL AS duration_days,
  'active' AS status,
  NULL AS prescribed_by,
  CURRENT_TIMESTAMP,
  CURRENT_TIMESTAMP
FROM
  norm_meeting_medications mm
  JOIN norm_meetings m ON m.id = mm.meeting_id
  JOIN norm_medication_master mmaster ON mmaster.id = mm.medication_id
  JOIN medications meds ON meds.name COLLATE utf8mb4_unicode_ci = mmaster.name COLLATE utf8mb4_unicode_ci
WHERE
  m.meeting_date IS NOT NULL
  AND YEAR (m.meeting_date) > 0
  AND NOT EXISTS (
    SELECT
      1
    FROM
      prescriptions p2
    WHERE
      p2.medication_id = meds.id
      AND p2.patient_id = m.patient_id
      AND p2.prescribed_date = m.meeting_date
  );

SET
  FOREIGN_KEY_CHECKS = 1;