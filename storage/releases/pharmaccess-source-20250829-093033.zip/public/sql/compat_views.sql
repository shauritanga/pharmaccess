-- Compatibility views to keep current UI working on normalized schema
-- Adjust column names to match your Eloquent models' expectations

-- diseases view (map icd_codes to diseases shape)
DROP VIEW IF EXISTS diseases;
CREATE VIEW diseases AS
SELECT id, name, code
FROM icd_codes;

-- disease_cases view (from visits + visit_diagnoses)
DROP VIEW IF EXISTS disease_cases;
CREATE VIEW disease_cases AS
SELECT
  vd.icd_id        AS disease_id,
  v.patient_id     AS patient_id,
  v.date_from      AS reported_date,
  'active'         AS status,
  'unknown'        AS severity
FROM visit_diagnoses vd
JOIN visits v ON v.id = vd.visit_id;

-- prescriptions view (from meetings + meeting_medications)
DROP VIEW IF EXISTS prescriptions;
CREATE VIEW prescriptions AS
SELECT
  mm.medication_id,
  m.patient_id,
  m.meeting_date    AS prescribed_date,
  mm.pills_received AS quantity
FROM meeting_medications mm
JOIN meetings m ON m.id = mm.meeting_id;

