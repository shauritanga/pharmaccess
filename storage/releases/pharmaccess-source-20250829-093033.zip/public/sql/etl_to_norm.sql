-- Populate norm_* tables from staging
SET
  NAMES utf8mb4;

SET
  FOREIGN_KEY_CHECKS = 0;

-- regions/districts/shehia minimal
INSERT INTO
  norm_regions (name)
SELECT
  'Unknown'
WHERE
  NOT EXISTS (
    SELECT
      1
    FROM
      norm_regions
    WHERE
      name = 'Unknown'
  );

INSERT INTO
  norm_districts (region_id, name)
SELECT
  r.id,
  s.name
FROM
  (
    SELECT DISTINCT
      TRIM(DistrictName) AS name
    FROM
      stage_VisitData
    WHERE
      DistrictName IS NOT NULL
      AND TRIM(DistrictName) <> ''
    UNION
    SELECT DISTINCT
      TRIM(District)
    FROM
      stage_Hfacility
    WHERE
      District IS NOT NULL
      AND TRIM(District) <> ''
  ) s
  JOIN norm_regions r ON r.name = 'Unknown'
  LEFT JOIN norm_districts d ON d.name = s.name
WHERE
  d.id IS NULL;

INSERT INTO
  norm_shehia (district_id, name)
SELECT
  d.id,
  s.shehia_name
FROM
  (
    SELECT DISTINCT
      TRIM(DistrictName) AS district_name,
      TRIM(Shehia) AS shehia_name
    FROM
      stage_VisitData
    WHERE
      Shehia IS NOT NULL
      AND TRIM(Shehia) <> ''
  ) s
  JOIN norm_districts d ON d.name = s.district_name
  LEFT JOIN norm_shehia sh ON sh.name = s.shehia_name
  AND sh.district_id = d.id
WHERE
  sh.id IS NULL;

-- facilities (if present)
INSERT INTO
  norm_hfacilities (
    id,
    name,
    legal_form,
    level,
    qpi_id,
    certificate_awarded_level,
    latitude,
    longitude,
    address,
    district_id,
    care_type
  )
SELECT
  HfID,
  HFName,
  LegalForm,
  HFLevel,
  QPID,
  certificateAwardedLevel,
  latitude,
  longitude,
  HFAddress,
  d.id,
  HFCareType
FROM
  stage_Hfacility h
  LEFT JOIN norm_districts d ON d.name = TRIM(h.District) ON DUPLICATE KEY
UPDATE name =
VALUES
  (name),
  legal_form =
VALUES
  (legal_form),
  level =
VALUES
  (level),
  qpi_id =
VALUES
  (qpi_id),
  certificate_awarded_level =
VALUES
  (certificate_awarded_level),
  latitude =
VALUES
  (latitude),
  longitude =
VALUES
  (longitude),
  address =
VALUES
  (address),
  district_id =
VALUES
  (district_id),
  care_type =
VALUES
  (care_type);

-- patients
INSERT INTO
  norm_patients (
    id,
    open_imis_number,
    name,
    gender,
    phone_number,
    district_id,
    shehia_id,
    date_joined
  )
SELECT
  gd.Patient_number,
  NULLIF(TRIM(gd.open_IMIS_number), ''),
  NULLIF(TRIM(gd.Patient_name), ''),
  CASE LOWER(TRIM(gd.Gender))
    WHEN 'm' THEN 'male'
    WHEN 'male' THEN 'male'
    WHEN 'f' THEN 'female'
    WHEN 'female' THEN 'female'
    ELSE NULL
  END,
  NULLIF(TRIM(gd.phone_number), ''),
  d.id,
  sh.id,
  NULL
FROM
  stage_GroupsDemographics gd
  LEFT JOIN norm_shehia sh ON sh.name = TRIM(gd.Shehia)
  LEFT JOIN norm_districts d ON d.id = sh.district_id ON DUPLICATE KEY
UPDATE open_imis_number =
VALUES
  (open_imis_number),
  name =
VALUES
  (name),
  gender =
VALUES
  (gender),
  phone_number =
VALUES
  (phone_number),
  district_id =
VALUES
  (district_id),
  shehia_id =
VALUES
  (shehia_id),
  date_joined =
VALUES
  (date_joined);

INSERT INTO
  norm_patients (id, gender, ppi_score, district_id)
SELECT DISTINCT
  v.InsureeID,
  CASE LOWER(TRIM(v.Gender))
    WHEN 'm' THEN 'male'
    WHEN 'male' THEN 'male'
    WHEN 'f' THEN 'female'
    WHEN 'female' THEN 'female'
    ELSE NULL
  END,
  NULLIF(TRIM(v.PPIScore), ''),
  d.id
FROM
  stage_VisitData v
  LEFT JOIN norm_districts d ON d.name = TRIM(v.DistrictName)
  LEFT JOIN norm_patients p ON p.id = v.InsureeID
WHERE
  p.id IS NULL;

-- icd codes
INSERT INTO
  norm_icd_codes (id, code, name)
SELECT
  ICDID,
  ICDCode,
  ICDName
FROM
  stage_tblICDCodes ON DUPLICATE KEY
UPDATE code =
VALUES
  (code),
  name =
VALUES
  (name);

-- visits
INSERT INTO
  norm_visits (
    id,
    patient_id,
    hfacility_id,
    matibabu_id,
    claim_admin_id,
    date_from,
    date_to,
    visit_context
  )
SELECT
  v.ClaimID,
  v.InsureeID,
  v.HFID,
  NULLIF(TRIM(v.MatibabuID), ''),
  v.ClaimAdminId,
  CASE
    WHEN v.DateFrom LIKE '%/%/%' THEN COALESCE(
      STR_TO_DATE (v.DateFrom, '%m/%e/%Y %H:%i'),
      STR_TO_DATE (v.DateFrom, '%m/%e/%Y')
    )
    WHEN v.DateFrom LIKE '____-__-__ __:__:__' THEN STR_TO_DATE (v.DateFrom, '%Y-%m-%d %H:%i:%s')
    WHEN v.DateFrom LIKE '____-__-__ __:__' THEN STR_TO_DATE (v.DateFrom, '%Y-%m-%d %H:%i')
    WHEN v.DateFrom LIKE '____-__-__' THEN STR_TO_DATE (v.DateFrom, '%Y-%m-%d')
    ELSE NULL
  END,
  CASE
    WHEN v.DateTo LIKE '%/%/%' THEN COALESCE(
      STR_TO_DATE (v.DateTo, '%m/%e/%Y %H:%i'),
      STR_TO_DATE (v.DateTo, '%m/%e/%Y')
    )
    WHEN v.DateTo LIKE '____-__-__ __:__:__' THEN STR_TO_DATE (v.DateTo, '%Y-%m-%d %H:%i:%s')
    WHEN v.DateTo LIKE '____-__-__ __:__' THEN STR_TO_DATE (v.DateTo, '%Y-%m-%d %H:%i')
    WHEN v.DateTo LIKE '____-__-__' THEN STR_TO_DATE (v.DateTo, '%Y-%m-%d')
    ELSE NULL
  END,
  NULLIF(TRIM(v.VisitType), '')
FROM
  stage_VisitData v ON DUPLICATE KEY
UPDATE patient_id =
VALUES
  (patient_id),
  hfacility_id =
VALUES
  (hfacility_id),
  matibabu_id =
VALUES
  (matibabu_id),
  claim_admin_id =
VALUES
  (claim_admin_id),
  date_from =
VALUES
  (date_from),
  date_to =
VALUES
  (date_to),
  visit_context =
VALUES
  (visit_context);

-- visit types
INSERT IGNORE INTO norm_visit_types (name)
SELECT
  t
FROM
  (
    SELECT
      TRIM(VisitType) AS t
    FROM
      stage_VisitData
    WHERE
      VisitType IS NOT NULL
    UNION
    SELECT
      TRIM(VisitType2)
    FROM
      stage_VisitData
    WHERE
      VisitType2 IS NOT NULL
    UNION
    SELECT
      TRIM(VisitType3)
    FROM
      stage_VisitData
    WHERE
      VisitType3 IS NOT NULL
  ) x
WHERE
  t <> '';

INSERT IGNORE INTO norm_visit_visit_types (visit_id, visit_type_id)
SELECT
  v.id,
  vt.id
FROM
  stage_VisitData s
  JOIN norm_visits v ON v.id = s.ClaimID
  JOIN norm_visit_types vt ON vt.name = TRIM(s.VisitType)
UNION
SELECT
  v.id,
  vt.id
FROM
  stage_VisitData s
  JOIN norm_visits v ON v.id = s.ClaimID
  JOIN norm_visit_types vt ON vt.name = TRIM(s.VisitType2)
UNION
SELECT
  v.id,
  vt.id
FROM
  stage_VisitData s
  JOIN norm_visits v ON v.id = s.ClaimID
  JOIN norm_visit_types vt ON vt.name = TRIM(s.VisitType3);

-- diagnoses
INSERT IGNORE INTO norm_visit_diagnoses (visit_id, icd_id, diag_rank)
SELECT
  ClaimID,
  ICDID,
  1
FROM
  stage_VisitData
WHERE
  ICDID IS NOT NULL
UNION ALL
SELECT
  ClaimID,
  ICDID1,
  2
FROM
  stage_VisitData
WHERE
  ICDID1 IS NOT NULL
UNION ALL
SELECT
  ClaimID,
  ICDID2,
  3
FROM
  stage_VisitData
WHERE
  ICDID2 IS NOT NULL
UNION ALL
SELECT
  ClaimID,
  ICDID3,
  4
FROM
  stage_VisitData
WHERE
  ICDID3 IS NOT NULL
UNION ALL
SELECT
  ClaimID,
  ICDID4,
  5
FROM
  stage_VisitData
WHERE
  ICDID4 IS NOT NULL;

-- services/items
INSERT IGNORE INTO norm_service_master (id, name)
SELECT DISTINCT
  ServiceID,
  COALESCE(
    NULLIF(TRIM(ServName), ''),
    CONCAT ('Service-', ServiceID)
  )
FROM
  stage_Services
WHERE
  ServiceID IS NOT NULL;

INSERT IGNORE INTO norm_item_master (id, name)
SELECT DISTINCT
  ItemID,
  COALESCE(
    NULLIF(TRIM(ItemName), ''),
    CONCAT ('Item-', ItemID)
  )
FROM
  stage_Items
WHERE
  ItemID IS NOT NULL;

INSERT IGNORE INTO norm_claim_services (id, visit_id, service_id, qty_provided)
SELECT
  ClaimServiceID,
  ClaimID,
  ServiceID,
  COALESCE(QtyProvided, 0)
FROM
  stage_Services;

INSERT IGNORE INTO norm_claim_items (id, visit_id, item_id, qty_provided)
SELECT
  ClaimItemID,
  ClaimID,
  ItemID,
  COALESCE(QtyProvided, 0)
FROM
  stage_Items;

-- meetings and meds
INSERT IGNORE INTO norm_medication_master (name)
SELECT DISTINCT
  TRIM(Medication_1)
FROM
  stage_GroupsMeetingData
WHERE
  Medication_1 IS NOT NULL
  AND TRIM(Medication_1) <> '';

INSERT IGNORE INTO norm_meetings (
  patient_id,
  meeting_date,
  systolic_bp,
  diastolic_bp,
  pr,
  fbs,
  rbs,
  weight_kg,
  height_cm,
  bmi
)
SELECT
  Patient_number,
  CASE
    WHEN Meeting_date LIKE '%/%/%' THEN COALESCE(
      STR_TO_DATE (Meeting_date, '%m/%e/%Y %H:%i'),
      STR_TO_DATE (Meeting_date, '%m/%e/%Y')
    )
    WHEN Meeting_date LIKE '____-__-__ __:__:__' THEN STR_TO_DATE (Meeting_date, '%Y-%m-%d %H:%i:%s')
    WHEN Meeting_date LIKE '____-__-__ __:__' THEN STR_TO_DATE (Meeting_date, '%Y-%m-%d %H:%i')
    WHEN Meeting_date LIKE '____-__-__' THEN NULLIF(Meeting_date, '0000-00-00')
    ELSE NULL
  END,
  Systolic_BP,
  Diastolic_BP,
  PR,
  FBS,
  RBS,
  Weight_KG,
  Height_cm,
  BMI
FROM
  stage_GroupsMeetingData;

INSERT IGNORE INTO norm_meeting_medications (
  meeting_id,
  medication_id,
  dose_mg,
  pills_per_day,
  pills_received
)
SELECT
  m.id,
  mm.id,
  g.num_of_mgs_1,
  g.num_of_pills_1,
  g.num_of_pills_received_1
FROM
  stage_GroupsMeetingData g
  JOIN norm_meetings m ON m.patient_id = g.Patient_number
  AND m.meeting_date = g.Meeting_date
  JOIN norm_medication_master mm ON mm.name = TRIM(g.Medication_1);

SET
  FOREIGN_KEY_CHECKS = 1;