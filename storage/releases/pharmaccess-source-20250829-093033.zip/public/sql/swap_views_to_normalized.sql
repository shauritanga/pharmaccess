-- Swap app to read from normalized norm_* tables via views
SET NAMES utf8mb4;

-- Rename original app tables to _old for safety (comment out if you want to keep both)
RENAME TABLE diseases TO diseases_old,
             disease_cases TO disease_cases_old,
             prescriptions TO prescriptions_old,
             patients TO patients_old;

-- Recreate views matching the original app tables
CREATE VIEW patients AS
SELECT p.id,
       COALESCE(p.gender,'male') AS gender,
       -- derive age and age_group from date_of_birth and stage fallback if needed (here default to 0/'18-35')
       0 AS age,
       '18-35' AS age_group,
       'middle' AS economic_status,
       COALESCE(p.district_id, 0) AS district_id,
       NULL AS created_at,
       NULL AS updated_at
FROM norm_patients p;

CREATE VIEW diseases AS
SELECT ic.id, ic.name, CONCAT('ICD code: ', ic.code) AS description,
       'infectious' AS category, NULL AS created_at, NULL AS updated_at
FROM norm_icd_codes ic;

CREATE VIEW disease_cases AS
SELECT ROW_NUMBER() OVER (ORDER BY v.id) AS id,
       ic.id AS disease_id,
       v.patient_id,
       COALESCE(v.date_from, v.date_to) AS reported_date,
       'active' AS status,
       'mild' AS severity,
       NULL AS created_at,
       NULL AS updated_at
FROM norm_visit_diagnoses vd
JOIN norm_visits v ON v.id = vd.visit_id
JOIN norm_icd_codes ic ON ic.id = vd.icd_id;

CREATE VIEW prescriptions AS
SELECT ROW_NUMBER() OVER (ORDER BY m.id) AS id,
       meds.id AS medication_id,
       m.patient_id,
       m.meeting_date AS prescribed_date,
       COALESCE(mm.pills_received, 0) AS quantity,
       CONCAT(COALESCE(mm.dose_mg, 0), ' mg') AS dosage,
       NULL AS duration_days,
       'active' AS status,
       NULL AS prescribed_by,
       NULL AS created_at,
       NULL AS updated_at
FROM norm_meeting_medications mm
JOIN norm_meetings m ON m.id = mm.meeting_id
JOIN norm_medication_master meds ON meds.id = mm.medication_id;

