-- ETL: Patients and Visits (with Diagnoses and Visit Types) from staging tables
SET
  NAMES utf8mb4;

SET
  FOREIGN_KEY_CHECKS = 0;

-- 1) Insert patients primarily from GroupsDemographics; fall back to VisitData InsureeID
INSERT INTO
  patients (
    id,
    open_imis_number,
    name,
    gender,
    date_of_birth,
    phone_number,
    ppi_score,
    district_id,
    shehia_id,
    date_joined
  )
SELECT
  gd.Patient_number AS id,
  NULLIF(TRIM(gd.open_IMIS_number), ''),
  NULLIF(TRIM(gd.Patient_name), ''),
  CASE LOWER(TRIM(gd.Gender))
    WHEN 'm' THEN 'male'
    WHEN 'male' THEN 'male'
    WHEN 'f' THEN 'female'
    WHEN 'female' THEN 'female'
    ELSE NULL
  END,
  NULL,
  NULLIF(TRIM(gd.phone_number), ''),
  NULL,
  d.id AS district_id,
  gd.date_joined
FROM
  stage_GroupsDemographics gd
  LEFT JOIN shehia sh ON sh.name = TRIM(gd.Shehia)
  LEFT JOIN districts d ON d.id = sh.district_id ON DUPLICATE KEY
UPDATE open_imis_number =
VALUES
  (open_imis_number),
  name =
VALUES
  (name),
  gender =
VALUES
  (gender),
  phone_number =
VALUES
  (phone_number),
  district_id =
VALUES
  (district_id),
  shehia_id =
VALUES
  (shehia_id),
  date_joined =
VALUES
  (date_joined);

-- Set patient shehia_id and district_id from GroupsDemographics.Shehia
UPDATE patients p
JOIN stage_GroupsDemographics gd ON gd.Patient_number = p.id
LEFT JOIN shehia sh ON sh.name = TRIM(gd.Shehia)
LEFT JOIN districts d ON d.id = sh.district_id
SET
  p.shehia_id = COALESCE(p.shehia_id, sh.id),
  p.district_id = COALESCE(p.district_id, d.id)
WHERE
  p.shehia_id IS NULL;

-- 2) Insert any missing patients from VisitData (InsureeID) with minimal attributes
INSERT INTO
  patients (id, gender, ppi_score, date_of_birth, district_id)
SELECT DISTINCT
  v.InsureeID AS id,
  CASE LOWER(TRIM(v.Gender))
    WHEN 'm' THEN 'male'
    WHEN 'male' THEN 'male'
    WHEN 'f' THEN 'female'
    WHEN 'female' THEN 'female'
    ELSE NULL
  END,
  NULLIF(TRIM(v.PPIScore), ''),
  NULL, -- DOB is INT; will be parsed later if format provided
  d.id
FROM
  stage_VisitData v
  LEFT JOIN districts d ON d.name = TRIM(v.DistrictName)
  LEFT JOIN patients p ON p.id = v.InsureeID
WHERE
  p.id IS NULL;

-- 3) Visits from VisitData
INSERT INTO
  visits (
    id,
    patient_id,
    hfacility_id,
    matibabu_id,
    claim_admin_id,
    date_from,
    date_to,
    visit_context
  )
SELECT
  v.ClaimID,
  v.InsureeID,
  v.HFID,
  NULLIF(TRIM(v.MatibabuID), ''),
  v.ClaimAdminId,
  STR_TO_DATE (v.DateFrom, '%m/%e/%Y %H:%i'),
  STR_TO_DATE (v.DateTo, '%m/%e/%Y %H:%i'),
  NULLIF(TRIM(v.VisitType), '')
FROM
  stage_VisitData v
  LEFT JOIN patients p ON p.id = v.InsureeID ON DUPLICATE KEY
UPDATE patient_id =
VALUES
  (patient_id),
  hfacility_id =
VALUES
  (hfacility_id),
  matibabu_id =
VALUES
  (matibabu_id),
  claim_admin_id =
VALUES
  (claim_admin_id),
  visit_context =
VALUES
  (visit_context);

-- 4) Visit types (VisitType2, VisitType3)
INSERT IGNORE INTO visit_types (name)
SELECT DISTINCT
  t
FROM
  (
    SELECT
      TRIM(VisitType) AS t
    FROM
      stage_VisitData
    WHERE
      VisitType IS NOT NULL
    UNION
    SELECT
      TRIM(VisitType2)
    FROM
      stage_VisitData
    WHERE
      VisitType2 IS NOT NULL
    UNION
    SELECT
      TRIM(VisitType3)
    FROM
      stage_VisitData
    WHERE
      VisitType3 IS NOT NULL
  ) x
WHERE
  t <> '';

INSERT IGNORE INTO visit_visit_types (visit_id, visit_type_id)
SELECT
  v.ClaimID,
  vt.id
FROM
  stage_VisitData s
  JOIN visits v ON v.id = s.ClaimID
  JOIN visit_types vt ON vt.name = TRIM(s.VisitType)
UNION
SELECT
  v.ClaimID,
  vt.id
FROM
  stage_VisitData s
  JOIN visits v ON v.id = s.ClaimID
  JOIN visit_types vt ON vt.name = TRIM(s.VisitType2)
UNION
SELECT
  v.ClaimID,
  vt.id
FROM
  stage_VisitData s
  JOIN visits v ON v.id = s.ClaimID
  JOIN visit_types vt ON vt.name = TRIM(s.VisitType3);

-- 5) Diagnoses from ICDID + ICDID1..4 (ranked)
INSERT IGNORE INTO visit_diagnoses (visit_id, icd_id, rank)
SELECT
  ClaimID,
  ICDID,
  1
FROM
  stage_VisitData
WHERE
  ICDID IS NOT NULL
UNION ALL
SELECT
  ClaimID,
  ICDID1,
  2
FROM
  stage_VisitData
WHERE
  ICDID1 IS NOT NULL
UNION ALL
SELECT
  ClaimID,
  ICDID2,
  3
FROM
  stage_VisitData
WHERE
  ICDID2 IS NOT NULL
UNION ALL
SELECT
  ClaimID,
  ICDID3,
  4
FROM
  stage_VisitData
WHERE
  ICDID3 IS NOT NULL
UNION ALL
SELECT
  ClaimID,
  ICDID4,
  5
FROM
  stage_VisitData
WHERE
  ICDID4 IS NOT NULL;

SET
  FOREIGN_KEY_CHECKS = 1;