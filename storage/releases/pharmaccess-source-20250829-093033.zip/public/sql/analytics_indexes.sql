-- Indexes tailored for dashboard analytics performance

-- visits: filter/group by date and facility
ALTER TABLE visits
  ADD INDEX idx_visits_date_from (date_from),
  ADD INDEX idx_visits_fac_date (hfacility_id, date_from);

-- visit_diagnoses: by disease then visit
ALTER TABLE visit_diagnoses
  ADD INDEX idx_vd_icd_visit (icd_id, visit_id);

-- meetings: time-based queries
ALTER TABLE meetings
  ADD INDEX idx_meet_date_patient (meeting_date, patient_id);

-- meeting_medications: by medication then meeting for trend aggregation
ALTER TABLE meeting_medications
  ADD INDEX idx_mm_med_meet (medication_id, meeting_id);

