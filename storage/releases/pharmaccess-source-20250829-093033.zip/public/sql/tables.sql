-- Table: VisitData
CREATE TABLE
    VisitData (
        ClaimID INT PRIMARY KEY,
        InsureeID INT,
        FamilyID INT,
        MatibabuID VARCHAR(255),
        PPIScore VARCHAR(255),
        Gender VARCHAR(255),
        DateFrom INT,
        DateTo INT,
        ICDID INT, -- Foreign key to tblICDCodes
        HFID INT, -- Foreign key to tblHF
        HFName VARCHAR(255),
        ClaimAdminId INT,
        ICDID1 INT,
        ICDID2 INT,
        ICDID3 INT,
        ICDID4 INT,
        VisitType VARCHAR(255),
        VisitType2 VARCHAR(255),
        VisitType3 VARCHAR(255),
        DOB INT,
        DistrictName VARCHAR(255),
        Shehia VARCHAR(255)
    );

-- Table: Services
CREATE TABLE
    Services (
        ClaimServiceID INT PRIMARY KEY,
        ClaimID INT, -- References VisitData.ClaimID
        ServiceID INT,
        ServName VARCHAR(255),
        QtyProvided INT
    );

-- Table: RiskProfile
CREATE TABLE
    RiskProfile (
        RiskProfileID INT PRIMARY KEY,
        InsureeID INT, -- References VisitData.InsureeID
        ClaimID INT, -- References VisitData.ClaimID
        RefClinic VARCHAR(255),
        SupportHelp VARCHAR(255),
        TimeReachClinic INT,
        VisitsDuringPreg INT,
        HealthConditions VARCHAR(255),
        PregnantBefore INT,
        AgeFirstChild INT,
        ChildrenBefore INT,
        ComplicationPreviousPregnancies VARCHAR(255),
        AttendHealthFacility VARCHAR(255)
    );

-- Table: Items
CREATE TABLE
    Items (
        ClaimItemID INT PRIMARY KEY,
        ClaimID INT, -- References VisitData.ClaimID
        ItemID INT,
        ItemName VARCHAR(255),
        QtyProvided INT
    );

-- Table: Hfacility
CREATE TABLE
    Hfacility (
        HfID INT PRIMARY KEY, -- Foreign key to tblHF
        HFName VARCHAR(255),
        LegalForm VARCHAR(255),
        HFLevel VARCHAR(255),
        QPID INT,
        certificateAwardedLevel INT,
        latitude DECIMAL(10, 6),
        longitude DECIMAL(10, 6),
        HFAddress VARCHAR(255),
        LocationId INT,
        HFCareType VARCHAR(255),
        District VARCHAR(255),
        Region VARCHAR(255)
    );

-- Table: GroupsDemographics
CREATE TABLE
    GroupsDemographics (
        Group_name VARCHAR(255),
        Patient_number INT PRIMARY KEY,
        Patient_name VARCHAR(255),
        open_IMIS_number VARCHAR(255),
        Age INT,
        Gender VARCHAR(255),
        Diagnosis_HT_DM_HT_DM VARCHAR(255),
        Shehia VARCHAR(255),
        phone_number VARCHAR(255),
        date_joined DATE
    );

-- Table: GroupsMeetingData
CREATE TABLE
    GroupsMeetingData (
        Patient_number INT, -- References GroupsDemographics.Patient_number
        Meeting_date DATE,
        Systolic_BP INT,
        Diastolic_BP INT,
        PR INT,
        FBS DECIMAL(5, 2),
        RBS DECIMAL(5, 2),
        Weight_KG DECIMAL(5, 2),
        Height_cm DECIMAL(5, 2),
        BMI DECIMAL(5, 2),
        Medication_1 VARCHAR(255),
        num_of_mgs_1 INT,
        num_of_pills_1 INT,
        num_of_pills_received_1 INT,
        PRIMARY KEY (Patient_number, Meeting_date) -- Composite key assuming unique per patient-meeting
    );