-- Refresh diseases and disease_cases from full ICD CSV
SET
  NAMES utf8mb4;

SET
  collation_connection = 'utf8mb4_unicode_ci';

SET
  FOREIGN_KEY_CHECKS = 0;

-- 1) Load staging ICDs (assumes load_staging.sql already run)
-- 2) Upsert diseases from staging ICDs
INSERT INTO
  diseases (
    name,
    description,
    category,
    created_at,
    updated_at
  )
SELECT
  s.ICDName,
  CONCAT ('ICD code: ', s.ICDCode),
  'infectious',
  CURRENT_TIMESTAMP,
  CURRENT_TIMESTAMP
FROM
  stage_tblICDCodes s ON DUPLICATE KEY
UPDATE description =
VALUES
  (description),
  updated_at = CURRENT_TIMESTAMP;

-- 3) Insert disease_cases from primary ICDID only (dedupe on unique triple)
INSERT INTO
  disease_cases (
    disease_id,
    patient_id,
    reported_date,
    status,
    severity,
    created_at,
    updated_at
  )
SELECT
  d.id,
  v.InsureeID,
  CASE
    WHEN v.DateFrom LIKE '%/%/%' THEN COALESCE(
      STR_TO_DATE (v.DateFrom, '%m/%e/%Y %H:%i'),
      STR_TO_DATE (v.DateFrom, '%m/%e/%Y')
    )
    WHEN v.DateFrom LIKE '____-__-__ __:__:__' THEN STR_TO_DATE (v.DateFrom, '%Y-%m-%d %H:%i:%s')
    WHEN v.DateFrom LIKE '____-__-__ __:__' THEN STR_TO_DATE (v.DateFrom, '%Y-%m-%d %H:%i')
    WHEN v.DateFrom LIKE '____-__-__' THEN STR_TO_DATE (v.DateFrom, '%Y-%m-%d')
    ELSE NULL
  END AS reported_date,
  'active',
  'mild',
  CURRENT_TIMESTAMP,
  CURRENT_TIMESTAMP
FROM
  stage_VisitData v
  JOIN stage_tblICDCodes ic ON ic.ICDID = v.ICDID
  JOIN diseases d ON d.name COLLATE utf8mb4_unicode_ci = ic.ICDName COLLATE utf8mb4_unicode_ci
  JOIN patients p ON p.id = v.InsureeID
  LEFT JOIN disease_cases dc ON dc.disease_id = d.id
  AND dc.patient_id = v.InsureeID
  AND dc.reported_date = CASE
    WHEN v.DateFrom LIKE '%/%/%' THEN COALESCE(
      STR_TO_DATE (v.DateFrom, '%m/%e/%Y %H:%i'),
      STR_TO_DATE (v.DateFrom, '%m/%e/%Y')
    )
    WHEN v.DateFrom LIKE '____-__-__ __:__:__' THEN STR_TO_DATE (v.DateFrom, '%Y-%m-%d %H:%i:%s')
    WHEN v.DateFrom LIKE '____-__-__ __:__' THEN STR_TO_DATE (v.DateFrom, '%Y-%m-%d %H:%i')
    WHEN v.DateFrom LIKE '____-__-__' THEN STR_TO_DATE (v.DateFrom, '%Y-%m-%d')
    ELSE NULL
  END
WHERE
  dc.id IS NULL;

SET
  FOREIGN_KEY_CHECKS = 1;