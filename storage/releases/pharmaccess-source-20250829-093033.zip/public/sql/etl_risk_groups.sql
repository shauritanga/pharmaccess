-- ETL: Risk Profiles and Groups from staging into normalized schema
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;

-- 1) Groups master
INSERT IGNORE INTO groups(name)
SELECT DISTINCT TRIM(Group_name)
FROM stage_GroupsDemographics
WHERE Group_name IS NOT NULL AND TRIM(Group_name) <> '';

-- 2) Group memberships
INSERT IGNORE INTO group_memberships(group_id, patient_id, date_joined)
SELECT g.id, gd.Patient_number, gd.date_joined
FROM stage_GroupsDemographics gd
JOIN groups g ON g.name = TRIM(gd.Group_name)
JOIN patients p ON p.id = gd.Patient_number;

-- 3) Risk profiles
INSERT IGNORE INTO risk_profiles (id, patient_id, visit_id, ref_clinic, support_help, time_reach_clinic, visits_during_preg, pregnant_before, age_first_child, children_before, attend_health_facility)
SELECT
  rp.RiskProfileID,
  rp.InsureeID,
  rp.ClaimID,
  rp.RefClinic,
  rp.SupportHelp,
  rp.TimeReachClinic,
  rp.VisitsDuringPreg,
  rp.PregnantBefore,
  rp.AgeFirstChild,
  rp.ChildrenBefore,
  rp.AttendHealthFacility
FROM stage_RiskProfile rp
LEFT JOIN patients p ON p.id = rp.InsureeID
LEFT JOIN visits v ON v.id = rp.ClaimID
WHERE p.id IS NOT NULL; -- ensure patient exists

-- 4) Risk profile conditions (store raw text for now)
INSERT IGNORE INTO risk_profile_conditions (risk_profile_id, condition_code, condition_text)
SELECT rp.RiskProfileID, 'RAW', NULLIF(TRIM(rp.HealthConditions), '')
FROM stage_RiskProfile rp
WHERE rp.HealthConditions IS NOT NULL AND TRIM(rp.HealthConditions) <> '';

SET FOREIGN_KEY_CHECKS=1;

