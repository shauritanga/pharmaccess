-- ETL: Geography (regions/districts/shehia) and Facilities from staging tables
SET NAMES utf8mb4;

-- 1) Ensure an 'Unknown' region exists for district rows without region info
INSERT INTO regions(name)
SELECT 'Unknown' WHERE NOT EXISTS (SELECT 1 FROM regions WHERE name='Unknown');

-- 2) Insert districts from staging data (distinct names)
INSERT INTO districts(region_id, name)
SELECT r.id, s.name
FROM (
  SELECT DISTINCT TRIM(District) AS name FROM stage_Hfacility WHERE District IS NOT NULL AND TRIM(District)<>''
  UNION
  SELECT DISTINCT TRIM(DistrictName) FROM stage_VisitData WHERE DistrictName IS NOT NULL AND TRIM(DistrictName)<>''
) s
JOIN regions r ON r.name='Unknown'
LEFT JOIN districts d ON d.name=s.name
WHERE d.id IS NULL;

-- 3) Insert shehia (requires district mapping by name)
INSERT INTO shehia(district_id, name)
SELECT d.id, s.shehia_name
FROM (
  SELECT DISTINCT TRIM(DistrictName) AS district_name, TRIM(Shehia) AS shehia_name
  FROM stage_VisitData
  WHERE Shehia IS NOT NULL AND TRIM(Shehia)<>''
) s
JOIN districts d ON d.name=s.district_name
LEFT JOIN shehia sh ON sh.name=s.shehia_name AND sh.district_id=d.id
WHERE sh.id IS NULL;

-- 4) Insert facilities from staging
INSERT INTO hfacilities (id, name, legal_form, level, qpi_id, certificate_awarded_level, latitude, longitude, address, district_id, care_type)
SELECT 
  HfID,
  HFName,
  LegalForm,
  HFLevel,
  QPID,
  certificateAwardedLevel,
  latitude,
  longitude,
  HFAddress,
  d.id AS district_id,
  HFCareType
FROM stage_Hfacility h
LEFT JOIN districts d ON d.name = TRIM(h.District)
ON DUPLICATE KEY UPDATE
  name=VALUES(name), legal_form=VALUES(legal_form), level=VALUES(level), qpi_id=VALUES(qpi_id),
  certificate_awarded_level=VALUES(certificate_awarded_level), latitude=VALUES(latitude), longitude=VALUES(longitude),
  address=VALUES(address), district_id=VALUES(district_id), care_type=VALUES(care_type);

