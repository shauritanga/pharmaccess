<!-- App footer starts -->
<div class="app-footer bg-white" style="margin-left:270px">
    <span>© Pharmaccess 2025</span>
</div>
<!-- App footer ends -->